# 放射線科専門医スマホクイズ

GitHub Pages にそのまま公開できる一式です。

## 公開手順

1. GitHubで新しいリポジトリを作成します。
2. このフォルダ内の `index.html` をアップロードします。
3. リポジトリの `Settings` → `Pages` を開きます。
4. `Build and deployment` の `Source` を `Deploy from a branch` にします。
5. Branchを `main`、フォルダを `/(root)` にして `Save` します。
6. 数分後、表示されたURLをSafariで開きます。
7. Safariの共有ボタンから「ホーム画面に追加」を選びます。

## 更新方法

新しい問題を追加した最新版の `index.html` に置き換えて、GitHubへ再アップロードします。
同じURLのまま最新版に更新されます。

## 注意

学習履歴・ミス登録は、開いた端末のブラウザ内に保存されます。
Safariの履歴やWebサイトデータを消すと、学習履歴も消える場合があります。
